-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2016 at 12:22 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `epl361_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `fagerstrom`
--

CREATE TABLE IF NOT EXISTS `fagerstrom` (
  `F_Num` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `Ans_1` char(2) DEFAULT NULL,
  `Ans_2` char(2) DEFAULT NULL,
  `Ans_3` char(2) DEFAULT NULL,
  `Ans_4` char(2) DEFAULT NULL,
  `Ans_5` char(2) DEFAULT NULL,
  `Ans_6` char(2) DEFAULT NULL,
  `subjectID` int(100) unsigned DEFAULT NULL,
  PRIMARY KEY (`F_Num`),
  KEY `subjectID` (`subjectID`),
  KEY `subjectID_2` (`subjectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `researcher`
--

CREATE TABLE IF NOT EXISTS `researcher` (
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `researcher`
--

INSERT INTO `researcher` (`username`, `password`) VALUES
('user1', '1234'),
('user2', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `rosenberg`
--

CREATE TABLE IF NOT EXISTS `rosenberg` (
  `R_num` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `Ans_1` char(2) DEFAULT NULL,
  `Ans_2` char(2) DEFAULT NULL,
  `Ans_3` char(2) DEFAULT NULL,
  `Ans_4` char(2) DEFAULT NULL,
  `Ans_5` char(2) DEFAULT NULL,
  `Ans_6` char(2) DEFAULT NULL,
  `Ans_7` char(2) DEFAULT NULL,
  `Ans_8` char(2) DEFAULT NULL,
  `Ans_9` char(2) DEFAULT NULL,
  `Ans_10` char(2) DEFAULT NULL,
  `subjectID` int(100) unsigned DEFAULT NULL,
  PRIMARY KEY (`R_num`),
  KEY `subjectID` (`subjectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `subjectID` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `FullName` varchar(200) NOT NULL,
  `Age` varchar(40) NOT NULL,
  `Sex` enum('M','F') NOT NULL,
  `Phone` varchar(200) NOT NULL,
  `Status` enum('0','1') NOT NULL,
  PRIMARY KEY (`subjectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbltemp`
--

CREATE TABLE IF NOT EXISTS `tbltemp` (
  `tempID` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `fagerstrom`
--
ALTER TABLE `fagerstrom`
  ADD CONSTRAINT `fk_fagerstrom_subject` FOREIGN KEY (`subjectID`) REFERENCES `subject` (`subjectID`);

--
-- Constraints for table `rosenberg`
--
ALTER TABLE `rosenberg`
  ADD CONSTRAINT `fk_rosenberg_subject` FOREIGN KEY (`subjectID`) REFERENCES `subject` (`subjectID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
