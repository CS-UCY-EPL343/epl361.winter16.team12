<?php
	session_start();
	include '_dbhandler.php';
	if(isset($_POST["Submit"])){
		if(!empty($_POST["answers1"])){
			$Q1 = $_POST['answers1'];
		}else{	$Q1 = null;}
		
		if(!empty($_POST["answers2"])){
			$Q2 = $_POST['answers2'];
		}else{	$Q2 = null;}
		
		if(!empty($_POST["answers3"])){
			$Q3 = $_POST['answers3'];
		}else{	$Q3 = null;}
		
		if(!empty($_POST["answers4"])){
			$Q4 = $_POST['answers4'];
		}else{	$Q4 = null;}
		
		if(!empty($_POST["answers5"])){
			$Q5 = $_POST['answers5'];
		}else{	$Q5 = null;}
		
		if(!empty($_POST["answers6"])){
			$Q6 = $_POST['answers6'];
		}else{	$Q6 = null;}

		if(!empty($_POST["answers7"])){
			$Q7 = $_POST['answers7'];
		}else{	$Q7 = null;}
		
		if(!empty($_POST["answers8"])){
			$Q8 = $_POST['answers8'];
		}else{	$Q8 = null;}
		
		if(!empty($_POST["answers9"])){
			$Q9 = $_POST['answers9'];
		}else{	$Q9 = null;}
		
		if(!empty($_POST["answers10"])){
			$Q10 = $_POST['answers10'];
		}else{	$Q10 = null;}

		$sid = $_SESSION['id'];

		// insert subjectID and Rosenberg answers into database
		$sql = "INSERT INTO rosenberg (Ans_1, Ans_2, Ans_3, Ans_4, Ans_5, Ans_6, Ans_7, Ans_8, Ans_9, Ans_10, subjectID) 
				VALUES ('$Q1', '$Q2', '$Q3', '$Q4','$Q5','$Q6','$Q7','$Q8','$Q9','$Q10','$sid')";

		$result = mysqli_query($conn, $sql);
		
		$_SESSION['message'] = 'Rosenberg results inserted successfully!';
		$_SESSION['usermsg'] = 'Subject ID: ';

	//header("location: ../new6.php");
	header("Location: new5B.php");
	}
?>

