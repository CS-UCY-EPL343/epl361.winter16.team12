<?php 
	session_start();
	include '_header.php';
	$_SESSION['error'] = '';
?>

<!DOCTYPE html>

<body onLoad="MM_preloadImages('img1.png.jpg')">
	<a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','img1.png.jpg',1)"></a>
	
	<div class="container">
		
		<a href="index.php"><img src="mg3.png" class="img-responsive" alt="SmokeFreeBrain" style="width:704px;height:164px;"></a>
		                    
		
		<br><br>
		
		<div class="topcorner">
			<a href="index.php">
							<span class="glyphicon glyphicon-log-out"></span> Logout
					</a>
		</div> <!-- end logout -->
		
		<center>
		<?php 
			if (!empty($_SESSION['username'])){
				if(($_SESSION['username'] == 'user1') or ($_SESSION['username'] == 'user2')){
					echo 'Logged in as: '.$_SESSION['username'];
				}
			}else{	echo 'Error accessing database! ';}
		?>
		
		<?php 
			if ($_SESSION['messageExc'] == ''){
				// do nothing...
			}else{	echo '<br>'.$_SESSION['messageExc'];}
		?>
		</center>
		
		<div class="content">
			<center><h2>Create New Subject</h2></center>
		</div><br>
			
		<div class="row">
			<div class="col-md-offset-3 col-md-6">
				<a class="btn btn-default" id="btn-exc" href="new3.php" role="button">Create New Subject</a><br /><br />
				<a class="btn btn-default" id="btn-exc" href="excelToPHP.php" role="button">Insert From Excel</a><br /><br />
				<center><a href="searchUser.php"> <font color="black">Search Subject</font></a></center>
			</div>
		</div><br /><br />
    </div> <!-- /container -->
</body>
</html>