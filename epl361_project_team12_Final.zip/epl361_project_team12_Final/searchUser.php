
<?php
// php code to search data in mysql database and set it in input text

$key = md5('epl361');
$salt = md5('epl361');

//Decrypt
function decrypt($string, $key){
    $string = rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, base64_decode($string), MCRYPT_MODE_ECB));
    return $string;
}


if(isset($_POST['search']))
{
    // id to search
    $id = $_POST['id'];
    
    $mysql_host = 'localhost';
    $mysql_user = 'smkana01';
    $mysql_pass = 'bravoo=11';
    $mysql_db = 'epl361_project';

    // connect to mysql
    $connect = mysqli_connect($mysql_host,$mysql_user,$mysql_pass,$mysql_db);
    
    // mysql search query
    $query = "SELECT `subjectID`, `FullName`, `Age`, `Sex`, `Phone`, `Status` FROM `subject` WHERE  `subjectID` = $id";
    
    $result = mysqli_query($connect, $query);
    
    // if id exist 
    // show data in inputs

    if(mysqli_num_rows($result) > 0)
    {
      while ($row = mysqli_fetch_array($result))
      {
        $fullname = decrypt($row['FullName'], $key);
        $age = $row['Age'];
        $sex = $row['Sex'];
        $phone = decrypt($row['Phone'], $key);
        $status = $row['Status'];
      }  
    }
    
    // if the id not exist
    // show a message and clear inputs
    else {
        $message = 'Sorry, credentials dont match!';
		$fullname = "";
		$age = "";
		$sex = "";
		$phone = "";
		$status = "";
    }
    
    
   // mysqli_free_result($result);
    mysqli_close($connect);
    
}

// in the first time inputs are empty
else{
    $fullname = "";
    $age = "";
    $sex = "";
    $phone = "";
    $status = "";
}


?>

<!DOCTYPE html>
<?php
	include '_header.php';
?>

		<!-- *********************** -->
	<body onLoad="MM_preloadImages('img1.png.jpg')">
	<a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','img1.png.jpg',1)"></a>
	
	<div class="container">
		
		<a href="index.php"><img src="mg3.png" class="img-responsive" alt="SmokeFreeBrain" style="width:704px;height:164px;"></a>
		
		<br>
		
		<div class="topcorner">
		<a href="index.php">
						<span class="glyphicon glyphicon-log-out"></span> Logout
				</a>
	</div> <!-- end logout -->
	
	<center>
		<?php if (!empty($message)): ?>
			<p><?= $message ?></p>
		<?php endif; ?>
	
	<h1>Search Subject</h1>
	
	</center>

		<div class="row">
			<div class="col-md-offset-3 col-md-6">
				<form action="searchUser.php" method="post"><!-- FORM -->
				  <div class="form-group">
					<label for="exampleInputEmail1">Insert ID</label>
					<input type="text" class="form-control" name="id" required placeholder="Fill Subject ID Only"><br />
					<label for="exampleInputEmail1">FullName</label>
					<input type="text" class="form-control" name="FullName" value="<?php echo $fullname;?>">
					<label for="exampleInputEmail1">Sex</label>
					<input type="text" class="form-control" name="sex" value="<?php echo $sex;?>">
					<label for="exampleInputEmail1">Phone</label>
					<input type="text" class="form-control" name="phone" value="<?php echo $phone;?>">
					<label for="exampleInputEmail1">Status</label>
					<input type="text" class="form-control" name="status" value="<?php echo $status;?>">
					<label for="exampleInputEmail1">Age</label>
					<input type="text" class="form-control" name="age"  value="<?php echo $age;?>">
				  </div>
				  <button type="submit" class="btn btn-default" name="search" value="Find">Search</button>
				  <br><br>
				  <center><a href="new4.php"> <font color="black">Go Back</font></a></center>
				</form>
			</div>
		</div><br />
    </div> <!-- /container -->
    </body>

</html><br /><br />
