<?php
session_start();
include '_dbhandler.php';
$uid = $_POST['uid'];
$pwd = $_POST['pwd'];

// check if username is user1 or user2 and password = 1234
if (($uid=='user1' or $uid=='user2') and $pwd==1234) {
	$sql = "SELECT * FROM researcher WHERE username='$uid' AND password='$pwd'";

	$result = mysqli_query($conn, $sql);

	if(!$row = mysqli_fetch_assoc($result)){
		echo "Your username or password is incorrect!";
	}else{
		$_SESSION['username'] = $row['username'];
		$_SESSION['usermsg'] = 'Subject created successfully with ID: ';

		header("Location: new4.php");
	}
}else{
	$_SESSION['error'] = 'Error! credentials dont match!';
	header("Location: index.php");
}