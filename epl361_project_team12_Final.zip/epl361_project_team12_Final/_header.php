<html>
<head profile="https://wwww.smokefreebrain.com">
	<title>SmokeFreeBrain </title> 
	<link rel="shortcut icon" href="http://smokefreebrain.eu/sfree-uploads/2016/01/SFB_logonew.png">
	
	<meta charset="UTF-8">
    
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="shortcut icon" href="C:\wamp\www\html_php_database\epl361\epl361_project_team12\index.php/favicon.ico"/>

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
	<!--<link href="https://fonts.googleapis.com/css?family=Comfortaa" rel="stylesheet">-->
	<link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">
	
<html>

    <head>

        <title> PHP FIND DATA </title>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
	
<style>
	body{
		background-color: #CCCCCC;
		padding-top: 20px;
	/*	
		font-family: 'comfortaa', cursive;*/
		font-family: 'Play', sans-serif; 
		font-size: 16px;
	}
	p  {
		font-family: 'Play', sans-serif;
		font-size: 17px;
	}
	.img-responsive{
		margin: auto;
	}
	.btn{
		border-radius: 5px;
		width: 100%;
		background: #FD8B2B;
		color: #fff;
	}
	.btn:hover{
		background: #EF6B38;
		color: #fff;
	}
	a.btn{
		border-radius: 5px;
		width: 20%;
	}
	#but.btn{
		border-radius: 5px;
		width: 20%;
	}
	#btn-exc{
		border-radius: 5px;
		width: 100%;
		height: 35px;
		font-size: 16px;
	}
	.container{
		border: 2px solid #fff;
	}
	.topcorner{
	   	position:absolute;
	   	top:0;
	   	right:0;
		font-size: 16px;
		padding-right: 18px;
  }
.topcorner a{
	   	text-decoration: none;
  }
</style>	
</head>




