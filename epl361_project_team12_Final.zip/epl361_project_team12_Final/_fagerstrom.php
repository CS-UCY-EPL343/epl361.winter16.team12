<?php
session_start();
include '_dbhandler.php';

// Get fagerstrom results from FORM and insert to database
if(isset($_POST["Submit"])){
	if(!empty($_POST["answers1"])){
		$Q1 = $_POST['answers1'];
	}else{	$Q1 = null;}
	
	if(!empty($_POST["answers2"])){
		$Q2 = $_POST['answers2'];
	}else{	$Q2 = null;}
	
	if(!empty($_POST["answers3"])){
		$Q3 = $_POST['answers3'];
	}else{	$Q3 = null;}
	
	if(!empty($_POST["answers4"])){
		$Q4 = $_POST['answers4'];
	}else{	$Q4 = null;}
	
	if(!empty($_POST["answers5"])){
		$Q5 = $_POST['answers5'];
	}else{	$Q5 = null;}
	
	if(!empty($_POST["answers6"])){
		$Q6 = $_POST['answers6'];
	}else{	$Q6 = null;}
		
		
		$sid = $_SESSION['id'];

		// insert subject and fagerstrom results to database
		$sql = "INSERT INTO fagerstrom (Ans_1, Ans_2, Ans_3, Ans_4, Ans_5, Ans_6, subjectID) VALUES ('$Q1', '$Q2', '$Q3', '$Q4','$Q5','$Q6','$sid')";
		$result = mysqli_query($conn, $sql);
		
		echo '<br />';
		$_SESSION['message'] = 'Fagerstrom results inserted successfully!';
		$_SESSION['usermsg'] = 'Subject ID: ';

	header("Location: new5R.php");
}

?>

