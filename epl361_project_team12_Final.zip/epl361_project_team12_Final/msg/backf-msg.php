<?php
	session_start();
	
	$_SESSION['message'] = 'Fagerstrom results already inserted! Select Back or Logout to End!';
	header("Location: ../new5B.php");
	
?>

