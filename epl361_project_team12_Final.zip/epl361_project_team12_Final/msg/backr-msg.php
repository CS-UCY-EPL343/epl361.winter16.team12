<?php
	session_start();
	
	$_SESSION['message'] = 'Rosenberg results already inserted! Select Back or Logout to End!';
	header("Location: ../new5B.php");
	
?>

