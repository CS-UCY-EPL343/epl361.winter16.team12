<?php
	session_start();
	
	$_SESSION['message'] = 'Fagerstrom results already inserted! Select Rosenberg!';
	header("Location: ../new5R.php");
	
?>

