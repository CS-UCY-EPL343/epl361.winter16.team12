<?php
	session_start();
	
	$_SESSION['message'] = 'Select fagerstrom first to continue!';
	header("Location: ../new5.php");
	
?>

