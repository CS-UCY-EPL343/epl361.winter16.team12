<?php
	session_start();
	
	$_SESSION['message'] = 'Fagerstrom results inserted successfully!';
	header("Location: new5.php");
	
?>

